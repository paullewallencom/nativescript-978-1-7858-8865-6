This chapter examples just contains just the tests, copy the code from Chapter 5, and add these tests to them.
the main test folder is the folder you leave at the root of your application;
it contains the samlpe mocha, Appium and ProxyQuire tests.

The app/test folder contains the NativeScript test module.  Don't forget to actually change the IP address of the server it needs to talk to.