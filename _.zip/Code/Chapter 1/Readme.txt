To run any example on your Emulator or Device; change into the Example Directory and run:

1.  npm install tns-core-modules

2a. nativescript platform add ios
	   - or -
2b. nativescript platform add android

3a. nativescript run ios --emulator
	   - or -
3b. nativescript run android --emulator